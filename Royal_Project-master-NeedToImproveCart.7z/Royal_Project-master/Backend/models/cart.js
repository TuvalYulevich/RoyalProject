var mongoose = require("mongoose");

var cartSchema = new mongoose.Schema({
    name:{
        type: String,
        required: true
    },
    price:{
        type: Number,
        required: true
    },
    countInStock:{
        type: Number,
        required: true
    },
    category:{
        type: String,
        required: true
    }
});

const Cart = mongoose.model('cart', cartSchema);

module.exports = Cart;
