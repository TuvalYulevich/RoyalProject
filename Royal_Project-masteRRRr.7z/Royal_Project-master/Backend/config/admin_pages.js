var bodyParser = require("body-parser");
var express = require("express");
var router = express.Router();
var path = require("path");
var modelproduct = require('../models/products');

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

router.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, '../../views/admin.html'));
});

router.post('/add', async function(req, res) {
  try {
    var newProduct = new modelproduct({
      name: req.body.name,
      description: req.body.description,
      price: req.body.price,
      countInStock: req.body.countInStock,
      imageUrl: req.body.imageUrl,
      category: req.body.category,
      id: req.body.id
    });

    await newProduct.save();

    console.log('Product added to the database');
    res.redirect('/admin/pages');
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

router.post('/remove', async function(req, res) {
    try {
      var productId = req.body.id;
      await modelproduct.deleteOne({ id: productId });
      console.log('Product removed from the database');
      res.redirect('/admin/pages');
    } catch (error) {
      console.error(error);
      res.status(500).send('Server Error');
    }
  });

module.exports = router;
